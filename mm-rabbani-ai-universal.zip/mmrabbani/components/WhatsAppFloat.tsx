import { MessageCircle } from 'lucide-react';
import { WA_LINK } from '@/lib/data';
export default function WhatsAppFloat(){return <a href={WA_LINK+'?text=Hi%20MM%20Rabbani%20AI'} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full bg-green-500 text-white shadow-2xl hover:scale-105 transition"><MessageCircle/></a>}
