# MM Rabbani AI

Your AI Team. Working 24/7.
Hire AI employees for Rs.5,000/month — YouTube automation, social media, chatbots, lead generation.

## Stack
- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + Framer Motion
- **Components**: shadcn-style UI + Lucide Icons
- **State**: localStorage (no backend needed)
- **Database**: Client-side vault system

## Pages
- **/** - Home with hero, stats, services overview
- **/services** - Full service catalog with activation modal
- **/dashboard** - Client dashboard (AI Command Center, Service Hub, File Vault, Billing)
- **/tools** - Free AI tools (no signup)
- **/contact** - Contact form + WhatsApp support

## Features
✅ AI Command Center - Generate content (TikTok scripts, captions, emails, etc)
✅ Service Hub - Activate/manage AI services with tool-specific controls
✅ File Vault - Save, download, organize AI outputs
✅ Live lead generation with CSV export
✅ AI support chatbot with smart replies
✅ Fully responsive (mobile-first design)
✅ No backend: auth and data use localStorage
✅ WhatsApp integration for conversions

## Quick Start

### Local Development
```bash
npm install
npm run dev
# Open http://localhost:3000
```

### Type Checking
```bash
npm run type-check
```

### Build for Production
```bash
npm run build
npm run start
```

## Deployment

### Universal Static Deployment
This project is configured for a static export. It does not require your hosting provider, a Node.js server, or a database.

Build the website:
```bash
npm install
npm run build
```

Next.js will create a production-ready `out/` folder. Upload the **contents of `out/`** to almost any static web host or hosting control panel.

Compatible options include:
- Netlify
- Cloudflare Pages
- GitHub Pages
- Firebase Hosting
- AWS S3 + CloudFront
- Any cPanel/shared hosting with static HTML support
- Any web server such as Apache or Nginx

For cPanel/shared hosting, upload the contents of `out/` into `public_html/`.

### Custom Domain
Point your domain's DNS records to whichever hosting provider you choose. The application itself does not lock you to a provider.

## Environment Variables
See `.env.example` for required variables (optional, all have defaults)

## Project Structure
```
app/
  ├── globals.css          # Tailwind + custom styles
  ├── layout.tsx           # Root layout
  ├── page.tsx             # Home page
  ├── services/page.tsx    # Services catalog
  ├── tools/page.tsx       # Free AI tools
  ├── contact/page.tsx     # Contact form
  └── dashboard/page.tsx   # Client dashboard
components/
  ├── ui/                  # Primitives (Button, Input)
  ├── dashboard/           # Dashboard modules
  └── *.tsx                # Layout components (Navbar, Footer, etc)
lib/
  ├── data.ts              # Services, contact info, constants
  ├── storage.ts           # localStorage helpers + vault
  ├── aiEngine.ts          # AI task generators
  └── utils.ts             # cn() helper

```

## License
© 2026 MM Rabbani AI. Built by Malik Mujtaba Rabbani.

## Support
- Email: mmmrmujtabarabbani@gmail.com
- WhatsApp: +92 3182 5801 00

## Universal hosting

The application is provider-neutral. Run `npm run build` and upload the generated `out/` directory to your preferred static host. See `HOSTING.md` for cPanel, Apache, Nginx, GitHub Pages, Netlify, Cloudflare Pages, Firebase Hosting, and S3-style deployment notes.
