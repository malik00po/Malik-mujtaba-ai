# Universal Deployment Guide

This project is a **static Next.js export**. It is not tied to any particular hosting company.

## 1. Build

```bash
npm install
npm run build
```

The finished website will be inside:

```text
out/
```

## 2. Upload

Upload everything inside `out/` to the document root of your hosting service.

### cPanel / Shared Hosting
Upload the contents of `out/` to `public_html/`.

### Netlify / Cloudflare Pages / Firebase / Similar
Upload or deploy the `out/` directory as the published site directory.

### GitHub Pages
Publish the contents of `out/` using GitHub Pages. For a project subpath, configure the repository/site base path before deployment.

### Apache / Nginx
Serve the `out/` directory as the website document root.

## 3. Domain

Connect your custom domain through the DNS settings of the hosting provider. No provider-specific code is required.

## Important

- The current AI tools are local deterministic generators; they do not call an external LLM API.
- The dashboard stores data in browser `localStorage`.
- WhatsApp buttons open the configured WhatsApp number.
- Because this is a static export, server-only features such as API routes, server-side authentication, and server databases are not included.
