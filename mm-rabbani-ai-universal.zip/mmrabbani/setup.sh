#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "MM Rabbani AI — provider-neutral static setup"
echo "Install dependencies with: npm install"
echo "Build static website with: npm run build"
echo "Upload the generated out/ folder to your preferred host."
