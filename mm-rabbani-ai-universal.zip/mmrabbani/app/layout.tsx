import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import AnimatedBackground from "@/components/AnimatedBackground";
import { Toaster } from "@/components/Toaster";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "MM Rabbani AI — Your AI Team. Working 24/7.",
  description: "Hire AI employees for Rs.5000/month. YouTube automation, social media, chatbots, lead generation — all done by AI.",
  openGraph: {
    type: "website",
    locale: "en_PK",
    title: "MM Rabbani AI",
    description: "Your AI Team. Working 24/7.",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <meta name="theme-color" content="#04050c" />
      </head>
      <body className={`${inter.variable} min-h-screen antialiased`}>
        <AnimatedBackground />
        <Navbar />
        <main className="relative z-10">{children}</main>
        <Footer />
        <WhatsAppFloat />
        <Toaster />
      </body>
    </html>
  );
}
