# Host it anywhere

This project is provider-neutral and configured as a static website.

## Build

```bash
npm install
npm run build
```

The `out/` directory is the deployable website.

## Upload

Upload the **contents** of `out/` to your host's public web directory.

Examples:

- cPanel: `public_html/`
- Apache: configured document root
- Nginx: configured document root
- Netlify: publish directory `out`
- Cloudflare Pages: deploy `out`
- GitHub Pages: publish the generated static files
- Firebase Hosting: use `out` as the hosting directory
- AWS S3: upload the contents to the bucket used for static website hosting

## Custom domain

Connect the domain using the DNS instructions from your chosen host. There are no provider-specific runtime dependencies.

## Local preview

After building, you can preview the static files with any static HTTP server. For example, if Python is installed:

```bash
python3 -m http.server 8080 --directory out
```

Then open `http://localhost:8080`.

## Important limitation

This version is intentionally static. The AI tools use local generators and the dashboard uses browser storage. Real AI APIs, server-side authentication, payments, webhooks, and a server database require a backend and cannot be provided by a static-only deployment.
