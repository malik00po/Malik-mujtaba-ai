export type ServiceTool = "youtube" | "social" | "chatbot" | "leadgen" | "agent";

export type Service = {
  id: string;
  name: string;
  price: string;
  desc: string;
  icon: "youtube" | "social" | "chatbot" | "website" | "leads" | "agent";
  features: string[];
  tool: ServiceTool;
};

export const SERVICES: Service[] = [
  {
    id: "youtube", name: "AI YouTube Automation", price: "Rs.15,000/mo", icon: "youtube", tool: "youtube",
    desc: "Full AI-run YouTube channel: scripts, titles, thumbnails, scheduling & uploads.",
    features: ["10 videos/mo", "Scripts + titles + hashtags", "Thumbnail designs", "SEO optimization"],
  },
  {
    id: "social", name: "AI Social Media Manager", price: "Rs.5,000/mo", icon: "social", tool: "social",
    desc: "AI posts for Instagram, TikTok, Facebook & LinkedIn every single day.",
    features: ["30 posts/mo", "Captions + hashtags", "Content calendar", "Engagement replies"],
  },
  {
    id: "whatsapp-bot", name: "WhatsApp AI Chatbot", price: "Rs.8,000 setup", icon: "chatbot", tool: "chatbot",
    desc: "24/7 AI chatbot on WhatsApp that answers customers instantly.",
    features: ["Auto-replies", "Order booking", "Lead capture", "Trained on your business"],
  },
  {
    id: "website-bot", name: "AI Website Chatbot", price: "Rs.10,000 setup", icon: "website", tool: "chatbot",
    desc: "Smart AI widget for your website that converts visitors into customers.",
    features: ["Instant answers", "Embed anywhere", "Lead forms", "Custom trained"],
  },
  {
    id: "leads", name: "AI Lead Generation Machine", price: "Rs.12,000/mo", icon: "leads", tool: "leadgen",
    desc: "AI finds and qualifies real leads in your niche, delivered weekly.",
    features: ["200+ leads/mo", "Niche targeting", "Verified contacts", "CRM ready export"],
  },
  {
    id: "agent", name: "Custom AI Agent Builder", price: "Rs.50,000", icon: "agent", tool: "agent",
    desc: "We build a custom AI agent for YOUR business. Anything you need.",
    features: ["Custom workflow", "Your data training", "API integrations", "30-day support"],
  },
];

export const WA_NUMBER = "923182580100";
export const WA_LINK = `https://wa.me/${WA_NUMBER}`;

export function waLink(message: string) {
  return `${WA_LINK}?text=${encodeURIComponent(message)}`;
}

export const CONTACT = {
  email: "mmmrmujtabarabbani@gmail.com",
  whatsappDisplay: "+92 3182 5801 00",
  whatsapp: WA_LINK,
};

export const MARQUEE_ITEMS = [
  "AI YouTube Automation",
  "AI Social Media Manager",
  "WhatsApp AI Chatbot",
  "AI Website Chatbot",
  "AI Lead Generation Machine",
  "Custom AI Agent Builder",
  "AI Content Writing",
  "AI Ad Campaigns",
  "AI Customer Support",
  "AI Data Scraping",
];
