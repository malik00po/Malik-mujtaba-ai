const IS_CLIENT = typeof window !== "undefined";

export function get<T>(key: string, fallback: T): T {
  if (!IS_CLIENT) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch (err) {
    console.warn(`Failed to read from localStorage: ${key}`, err);
    return fallback;
  }
}

export function set(key: string, value: unknown) {
  if (!IS_CLIENT) return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn(`Failed to write to localStorage: ${key}`, err);
  }
}

export type VaultItem = { id: string; title: string; content: string; date: string };

export function getVault(): VaultItem[] {
  return get<VaultItem[]>("mmai_vault", []);
}

export function addToVault(title: string, content: string) {
  try {
    const vault = getVault();
    vault.unshift({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title,
      content,
      date: new Date().toLocaleString(),
    });
    set("mmai_vault", vault);
    if (IS_CLIENT) window.dispatchEvent(new CustomEvent("mmai:vault"));
  } catch (err) {
    console.error("Failed to add to vault", err);
  }
}

export function removeFromVault(id: string) {
  try {
    set("mmai_vault", getVault().filter((v) => v.id !== id));
    if (IS_CLIENT) window.dispatchEvent(new CustomEvent("mmai:vault"));
  } catch (err) {
    console.error("Failed to remove from vault", err);
  }
}
