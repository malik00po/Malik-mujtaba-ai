function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function makeRng(seed: string) {
  let s = hash(seed) || 1;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function pick<T>(rng: () => number, arr: T[]): T {
  return arr[Math.floor(rng() * arr.length)];
}

export function capitalize(s: string) {
  return s.trim().replace(/\b\w/g, (c) => c.toUpperCase());
}

const HOOKS = [
  "POV: your business runs itself",
  "Stop doing this in 2026",
  "I replaced my entire team with AI",
  "This AI trick made me Rs.1,00,000",
  "Nobody talks about this",
  "Your competitors are already using this",
  "The 30-second rule that changes everything",
  "AI just did this for free",
  "3 tools you need this week",
  "I asked AI to run my business for 24 hours",
];
const BODIES = [
  "Here's the exact 3-step method.",
  "Quick 15-second tip you can use today.",
  "Watch till the end — it gets wild.",
  "This took me 2 minutes with AI.",
  "99% of creators skip this step.",
  "The math works out — I did it live.",
  "It's easier than you think.",
  "I broke down the whole process.",
];
const CTAS = [
  "Follow for daily AI hacks.",
  "Save this for later.",
  "Comment 'AI' and I'll send the template.",
  "Share this with a founder friend.",
  "Turn on notifications 🔔",
  "Check the link in bio.",
];

function extractName(prompt: string): string {
  const m = prompt.match(/(?:product|about|for)\s+["']?([A-Za-z0-9][A-Za-z0-9\s]{2,20}?)(?:["']|\.|,|$)/i);
  return m ? m[1].trim() : "";
}

function tiktokScripts(topic: string): string {
  const rng = makeRng(`${topic}tik`);
  const lines = ["🔥 30 TIKTOK SCRIPTS — AI GENERATED", "", `Topic: ${topic}`, ""];
  for (let i = 1; i <= 30; i++) {
    lines.push(`🎬 Script ${i}: ${pick(rng, HOOKS)}. ${pick(rng, BODIES)} ${pick(rng, CTAS)}`);
  }
  return lines.join("\n");
}

function productDescriptions(prompt: string): string {
  const rng = makeRng(`${prompt}prod`);
  const product = extractName(prompt) || "your product";
  const adjs = ["game-changing", "next-level", "effortless", "all-in-one", "premium", "lightning-fast", "beginner-friendly", "budget-friendly"];
  const results = ["saves you 10+ hours every week", "doubles your output in 30 days", "pays for itself in the first week", "scales with your business", "works while you sleep"];
  const auds = ["busy founders", "small businesses", "content creators", "agency owners", "e-commerce stores", "startups"];
  const lines = ["🛍️ 10 PRODUCT DESCRIPTIONS — AI GENERATED", "", `Product: ${product}`, ""];
  for (let i = 1; i <= 10; i++) {
    const a = pick(rng, adjs), r = pick(rng, results), au = pick(rng, auds);
    lines.push(
      `Description ${i}:`,
      `Meet ${product} — the ${a} solution built for ${au}. It ${r}, with zero learning curve.`,
      `✅ Saves time ✅ Boosts results ✅ Backed by real users`,
      `Order today and get exclusive launch pricing.`,
      ""
    );
  }
  return lines.join("\n");
}

function instagramCaptions(prompt: string): string {
  const rng = makeRng(`${prompt}ig`);
  const topic = extractName(prompt) || "your niche";
  const openers = [
    `Ready for ${topic}? 🚀`, `Everything about ${topic} in one post.`, `${topic} just got easier. 🔥`,
    `POV: you finally nailed ${topic}.`, `Save this ${topic} guide.`, `New to ${topic}? Start here.`,
    `The ${topic} secret nobody shares.`, `Your ${topic} game is about to level up.`,
  ];
  const middles = ["We tested it so you don't have to.", "Here's what nobody tells you.", "Full breakdown below 👇", "Trust us — it works.", "The results speak for themselves.", "Simple, but powerful."];
  const ctas = ["Drop a 🔥 if you agree.", "Tag someone who needs this.", "Follow for daily tips.", "Comment 'MORE' for part 2.", "Share this with your crew.", "Save this post."];
  const lines = ["📸 20 INSTAGRAM CAPTIONS — AI GENERATED", "", `Topic: ${topic}`, ""];
  for (let i = 1; i <= 20; i++) {
    lines.push(`Caption ${i}: ${pick(rng, openers)} ${pick(rng, middles)} ${pick(rng, ctas)}`);
  }
  lines.push("", "Suggested hashtags:", `#${topic.replace(/\s+/g, "")} #SocialMedia #ContentCreator #Marketing #Growth #AI #Trending #Viral #Business #MMRabbaniAI`);
  return lines.join("\n");
}

function emailSequences(prompt: string): string {
  const topic = extractName(prompt) || "your offer";
  const lines = ["📧 5-EMAIL SALES SEQUENCE — AI GENERATED", "", `Offer: ${topic}`, ""];
  const seq = [
    [`Subject: Quick question about ${topic}`, `Hey {{first_name}},\n\nI noticed you're interested in ${topic}. Wanted to reach out while it's fresh.\n\nReply to this email and I'll personally help you get started.\n\n— Your AI Team`],
    [`Subject: The ${topic} method (2 min read)`, `Hey {{first_name}},\n\nHere's the exact 3-step method for ${topic} that we use with 89 clients.\n\nStep 1: … Step 2: … Step 3: …\n\nWant me to apply it for you? Just hit reply.`],
    [`Subject: What 89 clients taught us about ${topic}`, `Hey {{first_name}},\n\nMost people overcomplicate ${topic}. After 89 client projects, we know what actually works.\n\nBook a free 15-min call and I'll show you.`],
    [`Subject: Last call on ${topic}`, `Hey {{first_name}},\n\nJust checking in — the ${topic} offer closes this week.\n\nIf it's not right for you, no worries. If it is, let's get you started today.`],
    [`Subject: You're in! (${topic} next steps)`, `Hey {{first_name}},\n\nWelcome aboard. Here's what happens next:\n1. We activate your AI within 48h\n2. You get dashboard access\n3. Your AI starts working 24/7\n\nTalk soon.`],
  ];
  seq.forEach(([subject, body], i) => lines.push(`Email ${i + 1}:`, subject, "", body, "", "— — —"));
  return lines.join("\n");
}

function blogOutline(prompt: string): string {
  const topic = extractName(prompt) || "your topic";
  return [
    "📝 BLOG POST OUTLINE — AI GENERATED", "",
    `Topic: ${topic}`, "",
    "Title ideas:",
    `1. ${topic}: The Complete Guide for 2026`,
    `2. Why ${topic} Matters More Than Ever`,
    `3. ${topic} — Mistakes, Myths & Proven Wins`, "",
    "Structure:",
    "• Intro — hook + why this matters",
    "• Section 1 — the fundamentals",
    "• Section 2 — step-by-step playbook",
    "• Section 3 — common mistakes to avoid",
    "• Section 4 — tools & resources",
    "• Conclusion — recap + strong CTA", "",
    `SEO keywords: ${topic}, AI automation, productivity`,
    `Meta description: Learn how ${topic} works in 2026 with this practical, no-fluff guide.`,
  ].join("\n");
}

function adCopy(prompt: string): string {
  const rng = makeRng(`${prompt}ad`);
  const topic = extractName(prompt) || "your offer";
  const headlines = [
    `${topic} — Try It Risk-Free`,
    `Why Everyone Is Talking About ${topic}`,
    `Get ${topic} Done in Minutes`,
    `The ${topic} Shortcut`,
    `Stop Paying More for ${topic}`,
  ];
  const bodies = [
    `Tired of wasting time on ${topic}? Our AI does it for you — fast, accurate, affordable.`,
    `Join 89+ businesses already using AI for ${topic}. Setup in 48 hours.`,
    `No team. No agency fees. Just results. ${topic} handled by AI, 24/7.`,
  ];
  const lines = ["🎯 5 AD COPY VARIANTS — AI GENERATED", "", `Offer: ${topic}`, ""];
  for (let i = 1; i <= 5; i++) {
    lines.push(`Variant ${i}:`, `Headline: ${headlines[i - 1]}`, `Body: ${pick(rng, bodies)}`, `CTA: ${pick(rng, ["Get Started Now", "Claim Your Offer", "Book a Free Demo", "Start Today"])}`, "");
  }
  return lines.join("\n");
}

function leadMagnet(prompt: string): string {
  const topic = extractName(prompt) || "your niche";
  return [
    "🧲 LEAD MAGNET — AI GENERATED", "",
    `Title: The 2026 ${topic} Playbook (Free Download)`, "",
    "Subtitle: Everything we learned running AI for 89 clients — in one guide.", "",
    "What's inside:",
    `• 10 proven ${topic} strategies`,
    "• Templates you can copy today",
    "• AI tools that do the heavy lifting",
    "• Case studies with real numbers", "",
    'CTA: "Download the Free Playbook" → capture name + email → deliver PDF → auto-email 3-day follow-up sequence.',
  ].join("\n");
}

function generalTask(prompt: string): string {
  const rng = makeRng(`${prompt}gen`);
  const steps = [
    "Break the task into 5 clear sub-tasks",
    "Draft the first version automatically",
    "Optimize with proven templates from 89 client projects",
    "Format for your target platform",
    "Deliver + suggest next actions",
  ];
  return [
    "🧠 AI TASK COMPLETE", "",
    `Task: ${prompt}`, "",
    "What I did:",
    ...steps.map((s, i) => `${i + 1}. ${s}`), "",
    "Sample output:",
    `"${pick(rng, HOOKS)}. ${pick(rng, BODIES)} ${pick(rng, CTAS)}"`, "",
    `To get the full version, type a more specific prompt like "Generate 30 TikTok scripts about ${extractName(prompt) || "your niche"}".`,
  ].join("\n");
}

export function runCommandCenter(prompt: string): string {
  const p = prompt.toLowerCase();
  if (p.includes("tiktok") || p.includes("script")) return tiktokScripts(prompt);
  if (p.includes("product")) return productDescriptions(prompt);
  if (p.includes("instagram") || p.includes("caption")) return instagramCaptions(prompt);
  if (p.includes("email")) return emailSequences(prompt);
  if (p.includes("blog") || p.includes("article")) return blogOutline(prompt);
  if (p.includes("ad") || p.includes("facebook")) return adCopy(prompt);
  if (p.includes("lead")) return leadMagnet(prompt);
  return generalTask(prompt);
}

export function youtubeKit(topic: string) {
  const rng = makeRng(`${topic}ytk`);
  const t = capitalize(topic) || "AI Automation";
  const titles = [
    `I Tried ${t} For 30 Days — Here's What Happened`,
    `${t}: The Complete Beginner's Guide 2026`,
    `Why ${t} Is Blowing Up Right Now`,
    `10 ${t} Mistakes You're Making (And How To Fix Them)`,
    `${t} Secrets Nobody Talks About`,
    `How I Make Money With ${t}`,
    `${t} vs Everything Else — Honest Review`,
    `The Truth About ${t} (Watch Before You Start)`,
    `7 Tools That Make ${t} 10x Easier`,
    `${t} Challenge: Day 1 to Day 30 Results`,
  ];
  const scripts: string[] = [];
  for (let i = 0; i < 10; i++) {
    scripts.push(`Script ${i + 1}: [HOOK] ${pick(rng, HOOKS)} — In this video I break down ${t} step by step. ${pick(rng, BODIES)} [CTA] ${pick(rng, CTAS)}`);
  }
  const hashtags = [`#${t.replace(/\s+/g, "")}`, "#YouTubeGrowth", "#AITools", "#MakeMoneyOnline", "#ContentCreator", "#DigitalMarketing", "#ViralVideo", "#FacelessChannel", "#Automation", "#MMRabbaniAI"];
  return { titles, scripts, hashtags };
}

export function socialKit(brand: string) {
  const rng = makeRng(`${brand}soc`);
  const b = capitalize(brand) || "Your Brand";
  const ideaTemplates = [
    (x: string) => `Behind the scenes: how ${x} creates its magic`,
    (x: string) => `5 mistakes brands like ${x} make`,
    (x: string) => `Customer story: how ${x} solved a real problem`,
    (x: string) => `3 quick wins from ${x}'s playbook`,
    (x: string) => `A day in the life of ${x}'s AI team`,
    (x: string) => `Myth vs fact: ${x} edition`,
    (x: string) => `${x} x [current trend] — challenge time`,
    (x: string) => `Before & after: the ${x} transformation`,
    (x: string) => `Why ${x} runs on AI`,
    (x: string) => `Poll: what should ${x} build next?`,
  ];
  const formats = ["Reel", "Carousel", "Story", "Static image", "Text post", "Video"];
  const ideas: string[] = [];
  for (let i = 1; i <= 30; i++) {
    ideas.push(`Post ${i}: ${pick(rng, ideaTemplates)(b)} — format: ${pick(rng, formats)}`);
  }
  const captions: string[] = [];
  for (let i = 1; i <= 10; i++) {
    captions.push(`Caption ${i}: ${pick(rng, HOOKS)}. ${pick(rng, BODIES)} ${pick(rng, CTAS)} #${b.replace(/\s+/g, "")}`);
  }
  const hashtags = [`#${b.replace(/\s+/g, "")}`, "#SocialMedia", "#ContentStrategy", "#InstagramTips", "#TikTok", "#AIForBusiness", "#Marketing", "#Growth", "#Reels", "#MMRabbaniAI"];
  return { ideas, captions, hashtags };
}

const FIRST = ["Ayesha", "Bilal", "Daniyal", "Emaan", "Farhan", "Hira", "Ibrahim", "Junaid", "Khadija", "Mahnoor", "Noman", "Omar", "Rania", "Saad", "Taha", "Umaima", "Waleed", "Zara", "Ali", "Fatima"];
const LAST = ["Khan", "Ahmed", "Malik", "Raza", "Hussain", "Qureshi", "Sheikh", "Chaudhry", "Anwar", "Siddiqui", "Baig", "Butt"];
const DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com"];
const CITIES = ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar", "Quetta", "Sialkot", "Gujranwala"];
const INTENTS = ["Hot — replied within 24h", "Warm — opened emails", "Cold — needs 2 follow-ups"];

export function leadGen(niche: string) {
  const rng = makeRng(`${niche}lead`);
  const rows: { name: string; company: string; email: string; phone: string; city: string; intent: string }[] = [];
  for (let i = 0; i < 50; i++) {
    const first = pick(rng, FIRST);
    const last = pick(rng, LAST);
    const company = `${capitalize(niche)} ${pick(rng, ["Solutions", "Hub", "Labs", "Enterprises", "Co", "Digital", "Pro", "Works"])}`;
    const email = `${first.toLowerCase()}.${last.toLowerCase()}@${pick(rng, DOMAINS)}`;
    const phone = `+92 3${pick(rng, ["00", "11", "22", "33", "44"])} ${Math.floor(1000000 + rng() * 8999999)}`;
    rows.push({ name: `${first} ${last}`, company, email, phone, city: pick(rng, CITIES), intent: pick(rng, INTENTS) });
  }
  return rows;
}

export function agentSpec(desc: string) {
  const rng = makeRng(`${desc}agent`);
  const name = `${pick(rng, ["Aurora", "Nova", "Cipher", "Atlas", "Lumen", "Vortex", "Pulse", "Echo"])} Agent`;
  const capabilities = [
    "Automates your core workflow end-to-end",
    "Trained on your business data & tone",
    "Connects to WhatsApp, email & your CRM",
    "Runs on a schedule — 24/7, no breaks",
    "Reports results in your dashboard",
  ];
  const integrations = ["WhatsApp Business API", "Gmail / Outlook", "Zapier / Make", "Your website (embed)", "Google Sheets / Airtable", "Telegram"];
  return [
    `🤖 AGENT BLUEPRINT — ${name}`, "",
    `Based on your brief: "${desc}"`, "",
    `Mission: ${pick(rng, ["Maximize revenue on autopilot", "Remove repetitive manual work from your team", "Turn every lead into a closed deal"])}`, "",
    "Core capabilities:",
    ...capabilities.map((c) => `• ${c}`), "",
    "Integrations included:",
    ...integrations.map((i) => `• ${i}`), "",
    "Build timeline: 14–21 days",
    "Investment: Rs.50,000 one-time (includes 30-day support)", "",
    'Next step: tap "Upgrade on WhatsApp" and we\'ll start building.',
  ].join("\n");
}

export function supportReply(q: string) {
  const p = q.toLowerCase();
  if (p.includes("price") || p.includes("cost") || p.includes("rs"))
    return "Our plans start at just Rs.5,000/month for the AI Social Media Manager. YouTube Automation is Rs.15,000/mo, WhatsApp chatbot Rs.8,000 setup, website chatbot Rs.10,000 setup, lead gen Rs.12,000/mo, and custom agents Rs.50,000 one-time. Which one interests you?";
  if (p.includes("youtube"))
    return "AI YouTube Automation is Rs.15,000/month. We handle 10 videos per month: scripts, titles, hashtags, thumbnails, scheduling, and SEO. You just approve and post — or we can handle that too.";
  if (p.includes("social"))
    return "The AI Social Media Manager (Rs.5,000/mo) generates 30 posts monthly with captions and hashtags, schedules them, and replies to comments. Perfect for Instagram, TikTok, Facebook and LinkedIn.";
  if (p.includes("chatbot") || p.includes("whatsapp") || p.includes("bot"))
    return "Our AI chatbots cost Rs.8,000 (WhatsApp) or Rs.10,000 (website) as a one-time setup. They answer customers 24/7, capture leads, and can be trained on your business info.";
  if (p.includes("lead"))
    return "The AI Lead Generation Machine delivers 200+ verified leads per month in your niche for Rs.12,000/mo. You can preview 50 sample leads inside your dashboard right now.";
  if (p.includes("custom") || p.includes("agent"))
    return "Custom AI agents are Rs.50,000 one-time. We build any automation you need — data scraping, CRM integration, internal tools — with 30 days of free support after launch.";
  if (p.includes("dashboard"))
    return "Your Client AI Dashboard is free with every plan. Log in with your email, then use the AI Command Center, Service Hub, File Vault, and Billing & Support tabs.";
  if (p.includes("free") || p.includes("tool"))
    return "You can try 3 free AI tools right now: YouTube Idea Generator, AI Caption Writer, and Business Name Generator — no signup needed. Go to /tools!";
  if (p.includes("refund"))
    return "We offer a 7-day money-back guarantee on setup fees if the service hasn't started. Monthly plans can be cancelled anytime before renewal.";
  if (p.includes("contact") || p.includes("human") || p.includes("call"))
    return "You can reach us anytime at mmmrmujtabarabbani@gmail.com or WhatsApp +92 3182 5801 00. We reply within 2 hours.";
  return "Great question! I'm here 24/7. For anything specific, tap the green WhatsApp button and we'll reply within 2 hours. Meanwhile, try the free tools or explore your dashboard tabs!";
}

export function captionWriter(topic: string, tone = "energetic") {
  const rng = makeRng(`${topic}${tone}cap`);
  const openers = [
    `Ready for ${topic}? 🚀`,
    `Everything you need to know about ${topic}, in one post.`,
    `${topic} just changed the game. 🔥`,
    `POV: you finally cracked ${topic}.`,
    `Stop scrolling — ${topic} deserves 30 seconds.`,
    `If you're into ${topic}, this is for you.`,
    `We went all-in on ${topic} so you don't have to.`,
    `The ${topic} guide nobody asked for, but everyone needs.`,
  ];
  const middles = [
    "We tested it so you don't have to.",
    "Here's what nobody tells you about it.",
    "Swipe through for the full breakdown.",
    "Save this for your next project.",
    "Your future self will thank you.",
    "The results honestly surprised us.",
    "It's simpler than it looks — promise.",
    "Do this one thing and watch it change.",
  ];
  const ctas = ["Drop a 🔥 if you agree.", "Tag someone who needs this.", "Follow for more content like this.", 'Comment "MORE" for part 2.', "Share this with your team.", "Save this post — you'll need it."];
  const captions: string[] = [];
  for (let i = 1; i <= 10; i++) {
    captions.push(`Caption ${i}: ${pick(rng, openers)} ${pick(rng, middles)} ${pick(rng, ctas)}`);
  }
  const hashtags = [`#${topic.replace(/\s+/g, "")}`, "#SocialMedia", "#ContentCreator", "#MarketingTips", "#AI", "#GrowthHack", "#TrendingNow", "#Viral", "#BusinessTips", "#Reels", "#MMRabbaniAI"];
  return { captions, hashtags, tone };
}

export function youtubeIdeas(topic: string) {
  const t = capitalize(topic) || "AI Automation";
  return [
    `${t} for beginners: where to start in 2026`,
    `I tried ${t} for 30 days — honest results`,
    `Top 10 tools that make ${t} 10x easier`,
    `The biggest ${t} mistakes (and how to fix them)`,
    `How to make money with ${t}`,
    `${t} vs everything else: which wins?`,
    `5 ${t} secrets the pros don't share`,
    `Why ${t} is exploding right now`,
    `A day in the life of a ${t} creator`,
    `The truth about ${t} (watch before you start)`,
  ].map((x) => `Video idea: ${x}`);
}

export function businessNames(keyword: string) {
  const rng = makeRng(`${keyword}biz`);
  const prefixes = ["Nova", "Bright", "Apex", "Zen", "Swift", "Prime", "Luxe", "Vertex", "Pure", "Vibe", "Alpha", "NextGen"];
  const suffixes = ["Labs", "Studios", "Co", "Hub", "Works", "Digital", "Group", "Solutions", "Pro", "Media", "Tech", "AI"];
  const k = capitalize(keyword) || "Your";
  const names: string[] = [];
  for (let i = 0; i < 15; i++) {
    const style = Math.floor(rng() * 3);
    if (style === 0) names.push(`${pick(rng, prefixes)} ${k}`);
    else if (style === 1) names.push(`${k}${pick(rng, suffixes)}`);
    else names.push(`${pick(rng, prefixes)}${k}${pick(rng, suffixes)}`);
  }
  return names;
}
